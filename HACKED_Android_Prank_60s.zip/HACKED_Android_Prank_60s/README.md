# HACKED – Android Prank (60-second edition)

A harmless Android Studio project. The prank runs only while this app is open.

## Behavior
- Opens to a hacker-terminal simulation with fake log messages.
- Plays a short, locally bundled synthetic electronic scream effect.
- Shows a 60-second countdown.
- Automatically stops the sound and prank after 60 seconds, revealing that it was a prank.
- User can exit sooner using STOP PRANK or Android Back.

## Safety
- No permissions requested.
- No network access, boot receiver, accessibility service, device-admin access, overlay permission, or system-setting changes.
- Does not intercept power or volume buttons.
- Does not auto-launch after reboot or prevent closing the app.

## Build the APK
1. Open this folder in Android Studio.
2. Allow Gradle to sync (internet may be needed to download Android build tools).
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
