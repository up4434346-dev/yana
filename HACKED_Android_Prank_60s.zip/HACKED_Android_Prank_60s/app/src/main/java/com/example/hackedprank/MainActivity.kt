package com.example.hackedprank

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaPlayer
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val green = Color.rgb(57, 255, 20)
    private val red = Color.rgb(255, 55, 55)
    private var player: MediaPlayer? = null
    private var timer: CountDownTimer? = null
    private var prankEnded = false
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var countdown: TextView
    private lateinit var closeButton: Button

    private val lines = listOf(
        "INITIALIZING REMOTE SESSION... [SIMULATED]",
        "BYPASSING FIREWALL... [FAKE]",
        "SCANNING DEVICE... [DEMO ONLY]",
        "ACCESSING MAINFRAME... [SIMULATED]",
        "WARNING: UNKNOWN SIGNAL DETECTED [FAKE]",
        "SYSTEM OVERRIDE... NOT ACTUALLY RUNNING",
        "CONNECTION TRACE: 0%  [ANIMATION ONLY]",
        "SECURITY ALERT: THIS IS A PRANK",
        "NO FILES ACCESSED • NO SETTINGS CHANGED"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildScreen()
        playScreamEffect()
        startLogAnimation()
        startOneMinuteTimer()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 16)
            setBackgroundColor(Color.rgb(3, 8, 5))
        }

        val header = TextView(this).apply {
            text = "⚠  HACKED // SIMULATION"
            textSize = 21f
            setTextColor(red)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(4, 14, 4, 12)
        }
        root.addView(header)

        status = TextView(this).apply {
            text = "SIMULATED SECURITY ALERT"
            textSize = 13f
            setTextColor(green)
            gravity = Gravity.CENTER
            setPadding(4, 4, 4, 8)
        }
        root.addView(status)

        countdown = TextView(this).apply {
            text = "TIME LEFT: 01:00"
            textSize = 18f
            setTextColor(red)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 14)
        }
        root.addView(countdown)

        val scroll = ScrollView(this)
        log = TextView(this).apply {
            textSize = 13f
            setTextColor(green)
            typeface = Typeface.MONOSPACE
            setLineSpacing(7f, 1f)
        }
        scroll.addView(log)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val disclosure = TextView(this).apply {
            text = "PRANK SIMULATION • NO SYSTEM CHANGES"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(4, 10, 4, 8)
        }
        root.addView(disclosure)

        closeButton = Button(this).apply {
            text = "STOP PRANK  ✕"
            textSize = 16f
            setTextColor(Color.BLACK)
            setBackgroundColor(green)
            setOnClickListener { endPrank(showReveal = true) }
        }
        root.addView(closeButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 56
        ))
        setContentView(root)
    }

    private fun addLog(line: String) {
        if (prankEnded) return
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        log.append("[$stamp] $line\n")
        val scroll = log.parent as? ScrollView
        scroll?.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun startLogAnimation() {
        val handler = android.os.Handler(mainLooper)
        val runnable = object : Runnable {
            var index = 0
            override fun run() {
                if (prankEnded) return
                addLog(lines[index % lines.size])
                status.text = if (index % 3 == 0) "SCANNING... [SIMULATED]"
                             else "PROCESS RUNNING... [FAKE]"
                if (index % 4 == 2) status.setTextColor(red)
                else status.setTextColor(green)
                index++
                handler.postDelayed(this, 4200L)
            }
        }
        handler.post(runnable)
        // Keep a reference-free handler loop scoped to the Activity; it stops on destroy.
        lifecycleHandler = handler
        logRunnable = runnable
    }

    private var lifecycleHandler: android.os.Handler? = null
    private var logRunnable: Runnable? = null

    private fun startOneMinuteTimer() {
        timer = object : CountDownTimer(60_000L, 1_000L) {
            override fun onTick(millisUntilFinished: Long) {
                val seconds = (millisUntilFinished / 1000L).toInt()
                countdown.text = "TIME LEFT: %02d:%02d".format(seconds / 60, seconds % 60)
            }

            override fun onFinish() {
                countdown.text = "TIME LEFT: 00:00"
                endPrank(showReveal = true)
            }
        }.start()
    }

    private fun playScreamEffect() {
        try {
            player = MediaPlayer.create(this, R.raw.scream)
            player?.setOnCompletionListener {
                it.release()
                if (player === it) player = null
            }
            player?.start()
        } catch (_: Exception) {
            // Sound is optional. The prank remains safe if playback is unavailable.
        }
    }

    private fun endPrank(showReveal: Boolean) {
        if (prankEnded) return
        prankEnded = true
        timer?.cancel()
        timer = null
        lifecycleHandler?.removeCallbacksAndMessages(null)
        lifecycleHandler = null
        logRunnable = null
        try { player?.stop() } catch (_: Exception) {}
        player?.release()
        player = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (showReveal) {
            status.setTextColor(green)
            status.text = "😂 YOU GOT PRANKED!"
            countdown.text = "SIMULATION FINISHED"
            addRevealLine()
            closeButton.text = "CLOSE APP"
            closeButton.setOnClickListener { finish() }
        } else {
            finish()
        }
    }

    private fun addRevealLine() {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        log.append("\n[$stamp] >>> JUST A PRANK. NOTHING WAS HACKED. <<<\n")
    }

    override fun onDestroy() {
        timer?.cancel()
        lifecycleHandler?.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (_: Exception) {}
        player?.release()
        player = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        endPrank(showReveal = false)
    }
}
